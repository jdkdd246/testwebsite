# GitHub Pages Starter

This is a tiny website to verify that GitHub Pages works for your account.

- `index.html` — your homepage
- `style.css` — styles
- `script.js` — a little interactivity

Edit files right on GitHub, commit, and Pages will redeploy automatically.
